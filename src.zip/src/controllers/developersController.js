const developersModel= require("../models/developersModel")
const batchModel= require("../models/batchModel")

const createDeveloper= async function (req, res) {
    let Developer = req.body
    let developerCreated = await developersModel.create(Developer)
    res.send({data: developerCreated})
}

const createBatch= async function (req, res) {
    let batch = req.body
    let batchCreated = await batchModel.create(batch)
    res.send({data: batchCreated})
}

const scholarship= async function (req, res) {
let developer = await developersModel.find({percentage:{$gte:70},gender:"Female"})
  res.send({data: developer})
}


const developers= async function (req, res) {
    let data= req.query.percentage
    let data1= req.query.program
    let dev = await developersModel.find({percentage:data,program:data1})
      res.send({data: dev})
    }






module.exports.createDeveloper= createDeveloper

module.exports.createBatch= createBatch

module.exports.scholarship= scholarship

module.exports.developers= developers

